<!--<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    
    <div class="video-background">
        <video autoplay muted loop class="background-video">
            <source src="foto/tes1.mp4" type="video/mp4">
        </video>
    </div>

    <div class="box">
        <form method="post" action="proses-login.php">
            <div class="group">
                <h1 class="h1">Login</h1>
            </div>

            <div class="group" style="margin-top: 30px;">
                <input name="username" required type="text" class="input" id="username">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label for="username">Username</label>
            </div>

            <div class="group" style="margin-top: 35px; margin-bottom: 10px;">
                <input name="password" required type="password" class="input" id="password">
                <span class="highlight"></span>
                <span class="bar"></span>
                <label for="password">Password</label>
            </div>
            <div class="group" style="margin-top: 20px;">
                <button type="submit">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
-->

<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: welcome.php");
  exit;
}

require_once "koneksi.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Query untuk mencari pengguna dengan username yang sesuai
        $query = "SELECT * FROM login WHERE username='$username'";
        $result = mysqli_query($link, $query);

        // Periksa apakah pengguna ditemukan
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            // Verifikasi password
            if (password_verify($password, $row['password'])) {
                // Password cocok, proses login
                echo "Login berhasil!";
                header("location:index1.php");

                // Password tidak cocok, tampilkan pesan error
                $password_err = "Invalid password. Please try again.";

                } else {
            // Pengguna tidak ditemukan, tampilkan pesan error
            $username_err = "No account found with that username.";
            }

            }
}

// Tutup koneksi
mysqli_close($link);
        
}

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body { 
            font: 14px sans-serif; 
        }
        .wrapper {
            width: 350px;
            padding: 20px;
            margin-top: 124px;
            margin-left: 500px;
            border: 2px solid grey;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2 style="margin-left: 110px;">Login</h2>
        <p>Silahkan masukkan Username dan Password</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($username_err)) ? 'has-error' : ''; ?>">
                <label>Username</label>
                <input type="text" name="username" class="form-control" value="<?php echo $username; ?>">
                <span class="help-block"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
                <span class="help-block"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Tidak Punya akun? <a href="register.php">Daftar Sekarang.</a>.</p>
        </form>
    </div>    
</body>
</html>